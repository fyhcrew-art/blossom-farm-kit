/*
 * This file is part of GADS.
 *
 * Copyright (c) 2022-2025 Nikola Shabanov
 *
 * This source code is licensed under the GNU Affero General Public License v3.0.
 * You may obtain a copy of the license at https://www.gnu.org/licenses/agpl-3.0.html
 */

package devices

import (
	"context"

	"GADS/common/models"
)

// PlatformDevice is the interface that each OS-specific device type implements.
// It provides a unified API for device lifecycle and app management,
// eliminating the need for switch/case on device.OS throughout the codebase.
type PlatformDevice interface {
	// Lifecycle
	Setup() error
	Reset(reason string)

	// Apps
	InstallApp(path string) error
	UninstallApp(bundleID string) error
	GetInstalledApps() ([]models.DeviceApp, error)
	GetInstalledAppBundleIDs() []string
	LaunchApp(bundleID string) error
	KillApp(bundleID string) error

	// State accessors
	GetUDID() string
	// GetSerial returns the transport-level identifier for local device commands
	// (adb -s etc.). Equal to the UDID unless the device identity is synthesized.
	GetSerial() string
	// IsEphemeral reports whether the device exists only in memory and must
	// never be persisted to the DB (e.g. discovered Android emulators).
	IsEphemeral() bool
	GetOS() string
	GetDBDevice() *models.DBDevice
	GetProviderState() string
	SetProviderState(state string)
	IsConnected() bool
	SetConnected(connected bool)
	GetHost() string
	SetHost(host string)

	// Hub sync - builds the lightweight update sent to the hub each second
	ToSyncUpdate() models.ProviderDeviceSync

	// Appium - returns platform-specific Appium server capabilities
	AppiumCapabilities() models.AppiumServerCapabilities

	// Infrastructure accessors
	GetLogger() models.CustomLogger
	GetContext() context.Context
	GetAppiumPort() string
	SetAppiumPort(port string)
	SetNewContext(ctx context.Context, cancel context.CancelFunc)

	// Appium state accessors
	GetAppiumSessionID() string
	SetAppiumSessionID(id string)
	SetAppiumUp(up bool)
	SetAppiumLastPingTS(ts int64)
	SetAppiumLastCommandTS(ts int64)
	SetHasAppiumSession(has bool)
	SetAppiumSessionCaps(caps map[string]interface{})
	GetAppiumSessionCaps() map[string]interface{}
	GetIsAppiumUp() bool

	// Runtime state accessors (provider-only fields on RuntimeState)
	GetIsResetting() bool
	SetIsResetting(v bool)
	GetHardwareModelValue() string
	SetHardwareModel(model string)
	GetInstalledAppIDs() []string
	SetInstalledAppIDs(apps []string)
}

// RemoteControllable extends PlatformDevice with capabilities for devices that support
// remote control, streaming, and screen interaction (Android, iOS).
// TV platforms (Tizen, WebOS) do not implement this interface.
type RemoteControllable interface {
	PlatformDevice

	// Only remote-controllable devices have stream ports
	GetStreamPort() string

	// Device info
	GetScreenSize() (width, height string, err error)
	GetHardwareModel() (string, error)

	// Rotation
	GetCurrentRotation() (string, error)
	ChangeRotation(rotation string) error
	GetCurrentRotationValue() string
	SetCurrentRotation(rotation string)

	// Stream settings
	ApplyStreamSettings() error
	UpdateStreamSettingsOnDevice() error
	GetStreamTargetFPS() int
	SetStreamTargetFPS(fps int)
	GetStreamJpegQuality() int
	SetStreamJpegQuality(q int)
	GetStreamScalingFactor() int
	SetStreamScalingFactor(f int)
	GetSupportedStreamTypes() []models.StreamType
	SetSupportedStreamTypes(types []models.StreamType)
}
