/*
 * This file is part of GADS.
 *
 * Copyright (c) 2022-2025 Nikola Shabanov
 *
 * This source code is licensed under the GNU Affero General Public License v3.0.
 * You may obtain a copy of the license at https://www.gnu.org/licenses/agpl-3.0.html
 */

package devices

import (
	"GADS/common"
	"GADS/common/db"
	"GADS/common/models"
	"GADS/provider/config"
	"GADS/provider/logger"
	"GADS/provider/providerutil"
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/gobwas/ws"
	"github.com/gobwas/ws/wsutil"
)

// AndroidDevice holds Android-specific runtime state alongside the shared RuntimeState.
type AndroidDevice struct {
	RuntimeState
	StreamPort              string                  // host port forwarded to device port 1991 (video stream)
	AndroidIMEPort          string                  // host port forwarded to device port 1993 (IME keyboard)
	AndroidRemoteServerPort string                  // host port forwarded to device port 1994 (remote control server)
	ADBPort                 string                  // host port forwarded to device adbd port 5555 (ADB tunnel)
	ActiveDisplayID         string                  // display ID used for screencap; empty = device default
	AvailableDisplays       []models.AndroidDisplay // all physical displays detected on the device
}

const adbTCPPort = "5555"

var remoteServerNetClient = &http.Client{
	Timeout: time.Second * 120,
}

// Port accessors for router access via type assertion.
func (d *AndroidDevice) GetStreamPort() string              { return d.StreamPort }
func (d *AndroidDevice) GetAndroidIMEPort() string          { return d.AndroidIMEPort }
func (d *AndroidDevice) GetAndroidRemoteServerPort() string { return d.AndroidRemoteServerPort }
func (d *AndroidDevice) GetADBPort() string                 { return d.ADBPort }

// Setup runs the full Android device provisioning sequence.
func (d *AndroidDevice) Setup() (retErr error) {
	d.SetupMutex.Lock()
	defer d.SetupMutex.Unlock()

	if time.Now().Before(d.setupBackoffUntil) {
		return nil
	}

	defer func() {
		switch {
		case retErr == nil:
			d.setupBackoffNext = 0
			d.setupBackoffUntil = time.Time{}
		case errors.Is(retErr, context.Canceled), errors.Is(retErr, context.DeadlineExceeded):
			// external cancellation — do not apply backoff
		default:
			if d.setupBackoffNext == 0 {
				d.setupBackoffNext = setupBackoffBase
			} else {
				d.setupBackoffNext = min(d.setupBackoffNext*2, setupBackoffMax)
			}
			d.setupBackoffUntil = time.Now().Add(d.setupBackoffNext)
		}
	}()

	d.SetProviderState("preparing")
	logger.ProviderLogger.LogInfof("android_device_setup", "Running setup for device `%v`", d.GetUDID())

	d.getHardwareModel()

	if err := d.updateScreenSizeIfNeeded(); err != nil {
		return d.resetWithError("update screen dimensions with adb", err)
	}
	if err := d.disableAutoRotation(); err != nil {
		return d.resetWithError("disable auto-rotation", err)
	}
	if err := d.allocatePorts(); err != nil {
		return d.resetWithError("allocate free host ports", err)
	}
	if err := d.enableADBTCPMode(); err != nil {
		return d.resetWithError("enable ADB TCP mode", err)
	}
	if err := d.cleanupOldApps(); err != nil {
		return err // already reset inside cleanupOldApps
	}
	if err := d.installGadsSettingsApp(); err != nil {
		return d.resetWithError("install GADS Settings", err)
	}
	time.Sleep(1 * time.Second)
	if err := d.pushGadsSettingsInTmpLocal(); err != nil {
		return fmt.Errorf("push GADS Settings to /tmp/local: %w", err)
	}
	time.Sleep(2 * time.Second)
	if err := d.startServicesAndStreaming(); err != nil {
		return err // already reset inside
	}
	if err := d.forwardAndSetupPorts(); err != nil {
		return err // already reset inside
	}
	if err := d.applyStreamConfig(); err != nil {
		return d.resetWithError("apply device stream settings", err)
	}
	if err := d.setupAppiumIfNeeded(); err != nil {
		return err
	}

	d.SetProviderState("live")
	return nil
}

func (d *AndroidDevice) updateScreenSizeIfNeeded() error {
	if d.DBDevice.ScreenHeight != "" && d.DBDevice.ScreenWidth != "" {
		return nil
	}
	logger.ProviderLogger.LogDebugf("android_device_setup", "Updating screen dimensions for device `%v`", d.GetUDID())
	if err := d.updateScreenSizeADB(); err != nil {
		return err
	}
	logger.ProviderLogger.LogDebugf("android_device_setup", "Successfully updated screen dimensions for device `%v`", d.GetUDID())
	return nil
}

func (d *AndroidDevice) allocatePorts() error {
	streamPort, err := providerutil.GetFreePort()
	if err != nil {
		return fmt.Errorf("could not allocate free host port for GADS-stream - %w", err)
	}
	d.StreamPort = streamPort

	imePort, err := providerutil.GetFreePort()
	if err != nil {
		return fmt.Errorf("could not allocate free host port for GADS Android IME - %w", err)
	}
	d.AndroidIMEPort = imePort

	remoteServerPort, err := providerutil.GetFreePort()
	if err != nil {
		return fmt.Errorf("could not allocate free host port for GADS Android remote control server - %w", err)
	}
	d.AndroidRemoteServerPort = remoteServerPort

	adbPort, err := providerutil.GetFreePort()
	if err != nil {
		return fmt.Errorf("could not allocate free host port for ADB tunnel - %w", err)
	}
	d.ADBPort = adbPort

	if d.DBDevice.AudioStreamEnabled && d.DBDevice.StreamType == models.AndroidWebRTCGadsH264StreamTypeId {
		audioPort, err := providerutil.GetFreePort()
		if err != nil {
			logger.ProviderLogger.LogWarnf("android_device_setup", "Could not allocate audio port for device `%v` - disabling audio stream: %v", d.GetUDID(), err)
			d.DBDevice.AudioStreamEnabled = false
		} else {
			d.DBDevice.AudioPort = audioPort
		}
	}
	return nil
}

func (d *AndroidDevice) cleanupOldApps() error {
	d.InstalledApps = d.GetInstalledAppBundleIDs()
	logger.ProviderLogger.LogDebugf("android_device_setup", "Updated installed apps for Android device `%v`", d.GetUDID())

	for _, pkg := range []string{"com.gads.settings", "com.gads.webrtc", "com.shamanec.stream", "com.gads.gads_ime"} {
		if slices.Contains(d.InstalledApps, pkg) {
			if err := d.UninstallApp(pkg); err != nil {
				logger.ProviderLogger.LogErrorf("android_device_setup", "Could not uninstall %s from Android device `%v` - %v", pkg, d.GetUDID(), err)
				d.Reset(fmt.Sprintf("Failed to uninstall %s from Android device.", pkg))
				return err
			}
			time.Sleep(3 * time.Second)
		}
	}
	return nil
}

func (d *AndroidDevice) startServicesAndStreaming() error {
	go d.startRemoteControlServer()
	time.Sleep(2 * time.Second)

	// Android 15 (API 35) QPR1 stops MediaProjection when the keyguard shows; disabling it
	// keeps capture-based streams (video and internal audio) alive on device farms.
	if d.SemVer != nil && d.SemVer.Major() >= 15 {
		d.disableKeyguard()
	}

	// Start the respective video stream
	if d.DBDevice.StreamType == models.AndroidWebRTCGadsH264StreamTypeId {
		go d.startH264Stream()
	} else {
		if err := d.addStreamRecordingPermissions(); err != nil {
			logger.ProviderLogger.LogErrorf("android_device_setup", "Could not add GADS Settings stream recording permissions on Android device `%v` - %v", d.GetUDID(), err)
			d.Reset("Failed to add GADS Settings stream recording permissions on Android device.")
			return err
		}
		time.Sleep(2 * time.Second)

		if d.SemVer.Major() >= 15 {
			if err := d.addStreamPostNotificationsPermission(); err != nil {
				logger.ProviderLogger.LogErrorf("android_device_setup", "Could not add GADS Settings POST_NOTIFICATIONS permissions on Android device `%v` - %v", d.GetUDID(), err)
				d.Reset("Failed to add GADS Settings POST_NOTIFICATIONS permissions on Android device.")
				return err
			}
			time.Sleep(1 * time.Second)
		}

		if err := d.startStreaming(); err != nil {
			logger.ProviderLogger.LogErrorf("android_device_setup", "Could not start GADS streaming on Android device `%v` - %v", d.GetUDID(), err)
			d.Reset("Failed to start GADS streaming on Android device.")
			return err
		}
	}
	time.Sleep(2 * time.Second)

	// Forward the video stream to the host
	if err := d.forwardStream(); err != nil {
		logger.ProviderLogger.LogErrorf("android_device_setup", "Could not forward GADS streaming port to host port %v for Android device `%v` - %v", d.StreamPort, d.GetUDID(), err)
		d.Reset("Failed to forward GADS-stream port to host port.")
		return err
	}

	// Audio streaming setup (non-fatal): a dedicated AudioService streams PCM over
	// WebSocket (device port 1992), independent of the video pipeline.
	d.setupAudioStreaming()
	return nil
}

func (d *AndroidDevice) forwardAndSetupPorts() error {
	// Setup GADS Android IME
	if err := d.setupIME(); err != nil {
		logger.ProviderLogger.LogErrorf("android_device_setup", "Failed to setup GADS Android IME for Android device `%v` - %v", d.GetUDID(), err)
		d.Reset("Failed to setup GADS Android IME.")
		return err
	}

	// Forward IME port
	if err := d.forwardIME(); err != nil {
		logger.ProviderLogger.LogErrorf("android_device_setup", "Could not forward GADS Android IME port for Android device `%v` - %v", d.GetUDID(), err)
		d.Reset("Failed to forward GADS Android IME port to host port.")
		return err
	}

	// Forward remote server port
	if err := d.forwardRemoteServer(); err != nil {
		logger.ProviderLogger.LogErrorf("android_device_setup", "Could not forward GADS Android Settings port for Android device `%v` - %v", d.GetUDID(), err)
		d.Reset("Failed to forward GADS Android Settings port to host port.")
		return err
	}

	// Forward ADB port for remote ADB tunnel
	if err := d.forwardADB(); err != nil {
		logger.ProviderLogger.LogErrorf("android_device_setup", "Could not forward ADB port for Android device `%v` - %v", d.GetUDID(), err)
		d.Reset("Failed to forward ADB port to host port.")
		return err
	}
	return nil
}

func (d *AndroidDevice) applyStreamConfig() error {
	if err := d.ApplyStreamSettings(); err != nil {
		return fmt.Errorf("could not apply device stream settings - %w", err)
	}
	if err := d.UpdateStreamSettingsOnDevice(); err != nil {
		return fmt.Errorf("could not update GADS stream settings on device - %w", err)
	}
	return nil
}

func (d *AndroidDevice) setupAppiumIfNeeded() error {
	if !config.ProviderConfig.SetupAppiumServers {
		return nil
	}
	// Uninstall old Appium packages before starting
	for _, pkg := range []string{"io.appium.settings", "io.appium.uiautomator2.server", "io.appium.uiautomator2.server.test"} {
		if slices.Contains(d.InstalledApps, pkg) {
			if err := d.UninstallApp(pkg); err != nil {
				logger.ProviderLogger.LogWarnf("android_device_setup", "Failed to uninstall %s on device %s - %s", pkg, d.GetUDID(), err)
			}
		}
	}
	return setupAppiumForDevice(d)
}

// AppiumCapabilities returns the Android-specific Appium server capabilities.
func (d *AndroidDevice) AppiumCapabilities() models.AppiumServerCapabilities {
	return models.AppiumServerCapabilities{
		UDID:           d.GetSerial(),
		AutomationName: "UiAutomator2",
		PlatformName:   "Android",
		DeviceName:     d.DBDevice.Name,
	}
}

// Reset overrides RuntimeState.Reset to free Android-specific ports.
func (d *AndroidDevice) Reset(reason string) {
	if d.ResetBase(reason) {
		// Remove the actual 'adb forward' rules, otherwise they linger on the host
		// forever (until provider restart) everi time the device gets re-setup
		d.removeForwardedPort(d.StreamPort)
		d.removeForwardedPort(d.AndroidIMEPort)
		d.removeForwardedPort(d.AndroidRemoteServerPort)
		d.removeForwardedPort(d.ADBPort)

		common.MutexManager.LocalDevicePorts.Lock()
		delete(providerutil.UsedPorts, d.StreamPort)
		delete(providerutil.UsedPorts, d.AndroidIMEPort)
		delete(providerutil.UsedPorts, d.AndroidRemoteServerPort)
		delete(providerutil.UsedPorts, d.ADBPort)
		common.MutexManager.LocalDevicePorts.Unlock()
	}
}

func (d *AndroidDevice) androidRemoteServerRequest(method, endpoint string, requestBody io.Reader) (*http.Response, error) {
	url := fmt.Sprintf("http://localhost:%s/%s", d.AndroidRemoteServerPort, endpoint)
	d.Logger.LogDebugf("androidRemoteServerRequest", "Calling `%s` for device `%s`", url, d.GetUDID())
	req, err := http.NewRequest(method, url, requestBody)
	if err != nil {
		return nil, err
	}
	if requestBody != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	return remoteServerNetClient.Do(req)
}

func (d *AndroidDevice) isStreamServiceRunning() (bool, error) {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "dumpsys", "activity", "services", d.getStreamServiceName())
	output, err := cmd.CombinedOutput()
	if err != nil {
		return false, fmt.Errorf("isStreamServiceRunning: Error executing `%s` with combined output - %s", cmd.Args, err)
	}
	if strings.Contains(string(output), "(nothing)") {
		return false, nil
	}
	return true, nil
}

func (d *AndroidDevice) stopStreamService() {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "am", "stopservice", d.getStreamServiceName())
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Failed to stop GADS-stream service properly - %s", err)
	}
}

func (d *AndroidDevice) installGadsSettingsApp() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Installing GADS Settings apk on device `%v`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "install", "-r", fmt.Sprintf("%s/gads-settings.apk", config.ProviderConfig.ProviderFolder))
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("installGadsSettingsApp: Error executing `%s` - %s", cmd.Args, err)
	}
	return nil
}

func (d *AndroidDevice) pushGadsSettingsInTmpLocal() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Pushing GADS Settings apk to /tmp/local on device `%v`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "push", fmt.Sprintf("%s/gads-settings.apk", config.ProviderConfig.ProviderFolder), "/data/local/tmp/gads-settings")
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("pushGadsSettingsInTmpLocal: Error executing `%s` - %s", cmd.Args, err)
	}
	return nil
}

func (d *AndroidDevice) startRemoteControlServer() {
	killCmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "pkill -f RemoteControlServerKt")
	_ = killCmd.Run()
	time.Sleep(1 * time.Second)

	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell",
		"CLASSPATH=/data/local/tmp/gads-settings app_process / com.shamanec.settings.RemoteControlServerKt 1994")

	if err := cmd.Start(); err != nil {
		logger.ProviderLogger.LogErrorf("device_setup", "Error executing `%s` for device `%v` - %v", cmd.Args, d.GetUDID(), err)
		d.Reset("Failed to execute GADS Remote server.")
		return
	}
	if err := cmd.Wait(); err != nil {
		logger.ProviderLogger.LogErrorf("device_setup", "startRemoteControlServer: Error waiting for command to finish, device `%v` - %v", d.GetUDID(), err)
		d.Reset("GADS Android remote server failed.")
	}
}

func (d *AndroidDevice) startH264Stream() {
	killCmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "pkill -f H264Server")
	_ = killCmd.Run()
	time.Sleep(1 * time.Second)

	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell",
		"CLASSPATH=/data/local/tmp/gads-settings app_process / com.shamanec.settings.server.H264Server")

	if err := cmd.Start(); err != nil {
		logger.ProviderLogger.LogErrorf("device_setup", "Error executing `%s` for device `%v` - %v", cmd.Args, d.GetUDID(), err)
		d.Reset("Failed to execute GADS H264 server.")
		return
	}
	if err := cmd.Wait(); err != nil {
		logger.ProviderLogger.LogErrorf("device_setup", "startH264Stream: Error waiting for command to finish, device `%v` - %v", d.GetUDID(), err)
		d.Reset("GADS Android H264 server failed.")
	}
}

func (d *AndroidDevice) setupIME() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Enabling GADS Android IME on device `%v`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "ime", "enable", "com.gads.settings/com.shamanec.settings.RemoteKeyboardIME")
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("enableGadsAndroidIME: Error executing `%s` - %s", cmd.Args, err)
	}
	time.Sleep(1 * time.Second)

	logger.ProviderLogger.LogInfof("android_device_setup", "Setting GADS Android IME as active on device `%v`", d.GetUDID())
	cmd = exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "ime", "set", "com.gads.settings/com.shamanec.settings.RemoteKeyboardIME")
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("setGadsAndroidIMEAsActive: Error executing `%s` - %s", cmd.Args, err)
	}
	return nil
}

func (d *AndroidDevice) addStreamRecordingPermissions() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Adding GADS-stream recording permissions on device `%v`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "appops", "set", d.getStreamServicePackageName(), "PROJECT_MEDIA", "allow")
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("addStreamRecordingPermissions: Error executing `%s` - %s", cmd.Args, err)
	}
	return nil
}

func (d *AndroidDevice) addStreamPostNotificationsPermission() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Adding GADS app post notification permissions on device `%v`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "pm", "grant", d.getStreamServicePackageName(), "android.permission.POST_NOTIFICATIONS")
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("addStreamPostNotificationsPermission: Error executing `%s` - %s", cmd.Args, err)
	}
	return nil
}

func (d *AndroidDevice) startStreaming() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Starting GADS-stream app on `%s`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "am", "start", "-n", d.getStreamServiceActivityName())
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("startStreaming: Error executing `%s` - %s", cmd.Args, err)
	}
	return nil
}

func (d *AndroidDevice) pressHomeButton() {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "input", "keyevent", "KEYCODE_HOME")
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogErrorf("android_device_setup", "pressHomeButton: Could not 'press' Home button - %v", err)
	}
}

func (d *AndroidDevice) forwardPort(devicePort, hostPort string) error {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "forward", "tcp:"+hostPort, "tcp:"+devicePort)
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("forwardPort: Error forwarding device port %s to host port %s - %s", devicePort, hostPort, err)
	}
	return nil
}

func (d *AndroidDevice) removeForwardedPort(hostPort string) {
	if hostPort == "" {
		return
	}
	// Use context.Background - d.Context may already be cancelled during Reset.
	cmd := exec.CommandContext(context.Background(), "adb", "-s", d.GetSerial(), "forward", "--remove", "tcp:"+hostPort)
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogDebugf("android_device_setup", "removeForwardedPort: Could not remove `adb` forward for host port %s, device `%v`, - %s", hostPort, d.GetUDID(), err)
	}
}

func (d *AndroidDevice) forwardStream() error {
	return d.forwardPort("1991", d.StreamPort)
}

func (d *AndroidDevice) forwardIME() error {
	return d.forwardPort("1993", d.AndroidIMEPort)
}

func (d *AndroidDevice) forwardRemoteServer() error {
	return d.forwardPort("1994", d.AndroidRemoteServerPort)
}

// forwardAudioStream forwards the device audio stream (device port 1992) to the
// host audio port allocated in allocatePorts().
func (d *AndroidDevice) forwardAudioStream() error {
	return d.forwardPort("1992", d.DBDevice.AudioPort)
}

// setupAudioStreaming provisions the device-side audio pipeline (a foreground AudioService
// streaming PCM over WS:1992) when enabled. All failures are non-fatal.
func (d *AndroidDevice) setupAudioStreaming() {
	if !d.DBDevice.AudioStreamEnabled {
		return
	}
	// Audio is only wired for the GADS H264 WebRTC stream.
	if d.DBDevice.StreamType != models.AndroidWebRTCGadsH264StreamTypeId {
		return
	}
	// Internal AudioPlaybackCapture requires Android 10+ (API 29).
	if d.DBDevice.AudioInputType == "internal" && d.SemVer != nil && d.SemVer.Major() < 10 {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Internal audio capture requires Android 10+ but device `%s` is on Android %s — disabling audio stream", d.GetUDID(), d.SemVer.String())
		d.DBDevice.AudioStreamEnabled = false
		return
	}

	if err := d.forwardAudioStream(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not forward audio stream port for device `%s` - %v", d.GetUDID(), err)
	}

	if d.DBDevice.AudioInputType == "microphone" {
		d.grantRecordAudioPermission()
		d.startAudioService()
		return
	}

	// Internal device audio (default): needs a MediaProjection token.
	if err := d.addStreamRecordingPermissions(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not grant PROJECT_MEDIA for audio capture on device `%s` - %v", d.GetUDID(), err)
	}
	d.startAudioService()
	d.startAudioProjectionActivity()
}

// audioServiceComponent returns the fully-qualified AudioService component: the applicationId
// is per-flavor (com.gads.settings) but the code namespace is com.shamanec.settings.
func (d *AndroidDevice) audioServiceComponent() string {
	return d.getStreamServicePackageName() + "/com.shamanec.settings.audio.AudioService"
}

// grantRecordAudioPermission grants RECORD_AUDIO to the GADS settings app. Required
// whenever a foreground service declares a foregroundServiceType containing "microphone".
func (d *AndroidDevice) grantRecordAudioPermission() {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell",
		"pm", "grant", d.getStreamServicePackageName(), "android.permission.RECORD_AUDIO")
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not grant RECORD_AUDIO to %s for device `%v` - %v", d.getStreamServicePackageName(), d.GetUDID(), err)
	}
}

// startAudioService starts the foreground AudioService, where AudioRecord works correctly
// (not possible in the app_process shell context used for the video H264Server).
func (d *AndroidDevice) startAudioService() {
	d.grantRecordAudioPermission()

	stopCmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell",
		"am", "stopservice", "-n", d.audioServiceComponent())
	_ = stopCmd.Run()

	audioInputType := d.DBDevice.AudioInputType
	if audioInputType == "" {
		audioInputType = "internal"
	}
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell",
		"am", "start-foreground-service", "-n", d.audioServiceComponent(),
		"--es", "audio_input_type", audioInputType)
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not start audio service for device `%v` - %v", d.GetUDID(), err)
	}
}

// startAudioProjectionActivity shows the system MediaProjection dialog; on approval the token
// is stored in MediaProjectionHolder for AudioService's internal AudioPlaybackCapture.
func (d *AndroidDevice) startAudioProjectionActivity() {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell",
		"am", "start", "-n", d.getStreamServicePackageName()+"/com.shamanec.settings.audio.AudioProjectionActivity")
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not start AudioProjectionActivity for device `%v` - %v", d.GetUDID(), err)
	}
}

// disableKeyguard disables the device lock screen via adb locksettings.
func (d *AndroidDevice) disableKeyguard() {
	logger.ProviderLogger.LogInfof("android_device_setup", "Disabling keyguard on Android 15+ device `%v` to keep MediaProjection capture alive on lock", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "locksettings", "set-disabled", "true")
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not disable keyguard for device `%v` - %v", d.GetUDID(), err)
	}
}

func (d *AndroidDevice) enableADBTCPMode() error {
	// Check if tcpip mode is already enabled to avoid restarting adbd unnecessarily
	checkCmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "getprop", "service.adb.tcp.port")
	var outBuffer bytes.Buffer
	checkCmd.Stdout = &outBuffer
	if err := checkCmd.Run(); err == nil {
		if strings.TrimSpace(outBuffer.String()) == adbTCPPort {
			logger.ProviderLogger.LogInfof("android_device_setup", "ADB TCP mode already enabled on device `%v`, skipping", d.GetUDID())
			return nil
		}
	}

	logger.ProviderLogger.LogInfof("android_device_setup", "Enabling ADB TCP mode on device `%v`", d.GetUDID())
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "tcpip", adbTCPPort)
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("enableADBTCPMode: Error executing `%s` - %s", cmd.Args, err)
	}
	// Wait for adbd to restart and USB to reconnect
	time.Sleep(2 * time.Second)
	return nil
}

func (d *AndroidDevice) forwardADB() error {
	return d.forwardPort(adbTCPPort, d.ADBPort)
}

func (d *AndroidDevice) updateScreenSizeADB() error {
	logger.ProviderLogger.LogInfof("android_device_setup", "Attempting to automatically update the screen size for device `%v`", d.GetUDID())

	var outBuffer bytes.Buffer
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "wm", "size")
	cmd.Stdout = &outBuffer
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("updateScreenSizeADB: Error executing `%s` - %s", cmd.Args, err)
	}

	output := outBuffer.String()
	lines := strings.Split(output, "\n")
	if len(lines) == 2 {
		splitOutput := strings.Split(lines[0], ": ")
		screenDimensions := strings.Split(splitOutput[1], "x")
		d.DBDevice.ScreenWidth = strings.TrimSpace(screenDimensions[0])
		d.DBDevice.ScreenHeight = strings.TrimSpace(screenDimensions[1])
	}
	if len(lines) == 3 {
		splitOutput := strings.Split(lines[1], ": ")
		screenDimensions := strings.Split(splitOutput[1], "x")
		d.DBDevice.ScreenWidth = strings.TrimSpace(screenDimensions[0])
		d.DBDevice.ScreenHeight = strings.TrimSpace(screenDimensions[1])
	}

	// Ephemeral devices are never persisted - the detected dimensions live on the
	// in-memory DBDevice only
	if d.IsEphemeral() {
		return nil
	}

	if err := db.GlobalMongoStore.AddOrUpdateDevice(&d.DBDevice); err != nil {
		return fmt.Errorf("Failed to upsert new device screen dimensions to DB - %s", err)
	}
	return nil
}

// GetInstalledAppBundleIDs returns the bundle identifiers (package names) of third-party installed apps.
func (d *AndroidDevice) GetInstalledAppBundleIDs() []string {
	installedApps := make([]string, 0)
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "cmd", "package", "list", "packages", "-3")

	var outBuffer bytes.Buffer
	cmd.Stdout = &outBuffer
	if err := cmd.Run(); err != nil {
		d.Logger.LogErrorf("get_installed_apps", "Error getting installed apps - %v", err)
		return installedApps
	}

	result := strings.TrimSpace(outBuffer.String())
	lines := regexp.MustCompile("\r?\n").Split(result, -1)
	for _, line := range lines {
		lineSplit := strings.Split(line, ":")
		if len(lineSplit) > 1 {
			installedApps = append(installedApps, lineSplit[1])
		}
	}
	return installedApps
}

// GetInstalledApps returns detailed info about installed apps via the GADS remote server.
func (d *AndroidDevice) GetInstalledApps() ([]models.DeviceApp, error) {
	var deviceApps = make([]models.DeviceApp, 0)

	runningAppsResp, err := d.androidRemoteServerRequest(http.MethodGet, "installed-apps", nil)
	if err != nil {
		d.Logger.LogErrorf("get_installed_apps", "Failed executing remote server request - %s", err.Error())
		return deviceApps, err
	}
	defer runningAppsResp.Body.Close()

	payload, err := io.ReadAll(runningAppsResp.Body)
	if err != nil {
		d.Logger.LogErrorf("get_installed_apps", "Failed reading remote server response body - %s", err.Error())
		return deviceApps, err
	}
	if err := json.Unmarshal(payload, &deviceApps); err != nil {
		d.Logger.LogErrorf("get_installed_apps", "Failed unmarshalling remote server response - %s", err.Error())
		return deviceApps, err
	}
	return deviceApps, nil
}

// UninstallApp uninstalls an app by package name.
func (d *AndroidDevice) UninstallApp(packageName string) error {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "uninstall", packageName)
	if err := cmd.Run(); err != nil {
		d.Logger.LogErrorf("uninstall_app", "Error uninstalling app `%s` - %v", packageName, err)
		return err
	}
	return nil
}

// InstallApp installs an app from a file in the provider folder.
func (d *AndroidDevice) InstallApp(appName string) error {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "install", "-r", fmt.Sprintf("%s/%s", config.ProviderConfig.ProviderFolder, appName))
	if err := cmd.Run(); err != nil {
		d.Logger.LogErrorf("install_app", "Error installing app `%s` - %v", appName, err)
		return err
	}
	return nil
}

func (d *AndroidDevice) disableAutoRotation() error {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "settings", "put", "system", "accelerometer_rotation", "0")
	if err := cmd.Run(); err != nil {
		return err
	}
	return nil
}

// GetCurrentRotation returns "portrait" or "landscape" based on the actual display
// rotation reported by the remote control server.
func (d *AndroidDevice) GetCurrentRotation() (string, error) {
	resp, err := d.androidRemoteServerRequest(http.MethodGet, "rotation", nil)
	if err != nil {
		return "portrait", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "portrait", err
	}
	if resp.StatusCode != http.StatusOK {
		return "portrait", fmt.Errorf("remote control server returned status %d - %s", resp.StatusCode, string(body))
	}

	var rotationResp struct {
		Rotation string `json:"rotation"`
	}
	if err := json.Unmarshal(body, &rotationResp); err != nil {
		return "portrait", err
	}
	return rotationResp.Rotation, nil
}

// ChangeRotation changes the device rotation to "portrait" or "landscape" via the
// remote control server, which verifies the screen actually rotated and reverts
// the pending user_rotation when it did not.
func (d *AndroidDevice) ChangeRotation(rotation string) error {
	reqBody, err := json.Marshal(struct {
		Rotation string `json:"rotation"`
	}{Rotation: rotation})
	if err != nil {
		return err
	}

	resp, err := d.androidRemoteServerRequest(http.MethodPost, "rotation", bytes.NewReader(reqBody))
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("remote control server returned status %d - %s", resp.StatusCode, string(body))
	}
	return nil
}

// UpdateStreamSettingsOnDevice sends stream settings to the device via WebSocket.
func (d *AndroidDevice) UpdateStreamSettingsOnDevice() error {
	u := url.URL{Scheme: "ws", Host: "localhost:" + d.StreamPort, Path: ""}
	// The H264 server needs a few seconds to bind its port after (re)start — retry the dial.
	var destConn net.Conn
	var err error
	for attempt := 0; attempt < 30; attempt++ {
		destConn, _, _, err = ws.DefaultDialer.Dial(context.Background(), u.String())
		if err == nil {
			break
		}
		select {
		case <-d.Context.Done():
			return fmt.Errorf("cancelled while waiting for device `%s` stream port - %w", d.GetUDID(), d.Context.Err())
		case <-time.After(500 * time.Millisecond):
		}
	}
	if err != nil {
		return fmt.Errorf("failed connecting to device `%s` stream port - %s", d.GetUDID(), err)
	}
	defer destConn.Close()

	socketMsg := fmt.Sprintf("targetFPS=%v:jpegQuality=%v:scalingFactor=%v",
		d.StreamTargetFPS, d.StreamJpegQuality, d.StreamScalingFactor)

	if d.DBDevice.StreamType == models.AndroidWebRTCGadsH264StreamTypeId {
		socketMsg = fmt.Sprintf("targetFPS=%v:scalingFactor=%v",
			d.StreamTargetFPS, d.StreamScalingFactor)
	}

	if err := wsutil.WriteServerMessage(destConn, ws.OpText, []byte(socketMsg)); err != nil {
		return fmt.Errorf("failed sending stream settings to stream websocket - %s", err)
	}
	return nil
}

func (d *AndroidDevice) getStreamServiceName() string {
	return "com.gads.settings/com.shamanec.settings.streaming.MjpegScreenCaptureService"
}

func (d *AndroidDevice) getStreamServicePackageName() string {
	return "com.gads.settings"
}

func (d *AndroidDevice) getStreamServiceActivityName() string {
	return "com.gads.settings/com.shamanec.settings.streaming.MjpegScreenCaptureActivity"
}

// GetScreenSize is not needed for Android (screen size is retrieved via ADB during setup).
func (d *AndroidDevice) GetScreenSize() (width, height string, err error) {
	return d.DBDevice.ScreenWidth, d.DBDevice.ScreenHeight, nil
}

// GetHardwareModel returns the hardware model string.
func (d *AndroidDevice) GetHardwareModel() (string, error) {
	return d.HardwareModel, nil
}

func (d *AndroidDevice) getHardwareModel() {
	brandCmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "getprop", "ro.product.brand")
	var outBuffer bytes.Buffer
	brandCmd.Stdout = &outBuffer
	if err := brandCmd.Run(); err != nil {
		d.HardwareModel = "Unknown"
	}
	brand := outBuffer.String()
	outBuffer.Reset()

	modelCmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "getprop", "ro.product.model")
	modelCmd.Stdout = &outBuffer
	if err := modelCmd.Run(); err != nil {
		d.HardwareModel = "Unknown"
		return
	}
	model := outBuffer.String()
	d.HardwareModel = fmt.Sprintf("%s %s", strings.TrimSpace(brand), strings.TrimSpace(model))
}

// fetchAndSetDisplays queries the device for available physical displays via
// `dumpsys SurfaceFlinger --display-id` and stores them in AvailableDisplays.
// ActiveDisplayID is set to the first display if it has not been set yet.
// A failure is non-fatal — the device falls back to screencap without -d.
func (d *AndroidDevice) fetchAndSetDisplays() {
	displays, err := getAndroidDisplayIDs(d.GetSerial())
	if err != nil {
		logger.ProviderLogger.LogWarnf("android_device_setup", "Could not detect displays for device `%s`: %s", d.GetUDID(), err)
		return
	}
	d.AvailableDisplays = displays
	ids := make([]string, len(displays))
	for i, disp := range displays {
		ids[i] = fmt.Sprintf("%s (%s)", disp.ID, disp.Name)
	}
	logger.ProviderLogger.LogInfof("android_device_setup", "Detected %d display(s) for device `%s`: %s", len(displays), d.GetUDID(), strings.Join(ids, ", "))

	if len(displays) > 0 && d.ActiveDisplayID == "" {
		d.ActiveDisplayID = displays[0].ID
		logger.ProviderLogger.LogInfof("android_device_setup", "Active display set to %s (%s) for device `%s`", displays[0].ID, displays[0].Name, d.GetUDID())
	}
}

// GetActiveDisplayID returns the currently selected display ID for screencap.
func (d *AndroidDevice) GetActiveDisplayID() string { return d.ActiveDisplayID }

// SetActiveDisplayID sets the display ID used for subsequent screenshots.
func (d *AndroidDevice) SetActiveDisplayID(id string) {
	prev := d.ActiveDisplayID
	d.ActiveDisplayID = id
	d.GetLogger().LogInfof("display", "Active display changed: %s -> %s", prev, id)
}

// GetAvailableDisplays returns all physical displays detected on the device.
// Always returns a non-nil slice so callers receive "[]" rather than "null" in JSON.
func (d *AndroidDevice) GetAvailableDisplays() []models.AndroidDisplay {
	if d.AvailableDisplays == nil {
		return []models.AndroidDisplay{}
	}
	return d.AvailableDisplays
}

// getAndroidDisplayIDs runs dumpsys SurfaceFlinger --display-id and returns parsed displays.
func getAndroidDisplayIDs(serial string) ([]models.AndroidDisplay, error) {
	var out bytes.Buffer
	cmd := exec.Command("adb", "-s", serial, "shell", "dumpsys", "SurfaceFlinger", "--display-id")
	cmd.Stdout = &out
	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("dumpsys SurfaceFlinger --display-id: %w", err)
	}
	displays := parseAndroidDisplayIDs(out.String())
	if len(displays) == 0 {
		return nil, fmt.Errorf("no display IDs found in SurfaceFlinger output")
	}
	return displays, nil
}

// displayLineRe matches a physical display line from `dumpsys SurfaceFlinger --display-id`:
//
//	Display 4630947175568309891 (HWC display 0): port=131 ...
//	Display 4630946481096930692 (HWC display 3): port=132 ...
//
// Group 1 = 64-bit display ID (passed to screencap -d).
// Group 2 = display type string (e.g. "HWC display 0", "Virtual display").
var displayLineRe = regexp.MustCompile(`(?m)^Display\s+(\d+)\s+\(([^)]+)\)`)

// hwcNumberRe extracts the HWC index from "HWC display 3".
var hwcNumberRe = regexp.MustCompile(`HWC display\s+(\d+)`)

// parseAndroidDisplayIDs extracts physical display IDs from `dumpsys SurfaceFlinger --display-id`.
// Virtual displays (e.g. screen capture sinks) are excluded.
// Displays are named using their HWC index when available.
func parseAndroidDisplayIDs(output string) []models.AndroidDisplay {
	var displays []models.AndroidDisplay
	for _, m := range displayLineRe.FindAllStringSubmatch(output, -1) {
		id := m[1]
		typeStr := m[2]

		// Skip virtual displays — they are not physical screens.
		if strings.Contains(strings.ToLower(typeStr), "virtual") {
			continue
		}

		name := typeStr // fallback: use raw type string as name
		if hwc := hwcNumberRe.FindStringSubmatch(typeStr); len(hwc) == 2 {
			name = fmt.Sprintf("HWC display %s", hwc[1])
		}

		displays = append(displays, models.AndroidDisplay{ID: id, Name: name})
	}
	return displays
}

// LaunchApp is not supported for Android via this interface (use Appium).
func (d *AndroidDevice) LaunchApp(bundleID string) error {
	return fmt.Errorf("LaunchApp not supported for Android via this interface")
}

// KillApp force-stops an Android app by package name.
func (d *AndroidDevice) KillApp(bundleIdentifier string) error {
	cmd := exec.CommandContext(d.Context, "adb", "-s", d.GetSerial(), "shell", "am", "force-stop", bundleIdentifier)
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("KillApp: Failed killing app with package name `%s` via adb shell", bundleIdentifier)
	}
	return nil
}

// ApplyStreamSettings applies stream settings from DB to the device runtime state.
func (d *AndroidDevice) ApplyStreamSettings() error {
	return applyDeviceStreamSettings(d)
}

func DeleteAndroidSharedStorageFile(serial string, filePath string) error {
	deleteFileCmd := exec.Command("adb", "-s", serial, "shell", "rm", fmt.Sprintf("\"%s\"", filePath))
	_, err := deleteFileCmd.Output()
	return err
}

func PullAndroidSharedStorageFile(serial string, filePath string, fileName string) (string, error) {
	var tempFilePath = filepath.Join(os.TempDir(), fileName)
	pullFileCmd := exec.Command("adb", "-s", serial, "pull", filePath, tempFilePath)
	_, err := pullFileCmd.Output()
	return tempFilePath, err
}

var (
	androidOfflineReconnectMu sync.Mutex
	androidOfflineReconnectAt = map[string]time.Time{}
)

// cooldown of 30s prevents reconnect spam on each 1-second polling tick
func reconnectOfflineAndroid(serial string) {
	const cooldown = 30 * time.Second

	androidOfflineReconnectMu.Lock()
	if last, ok := androidOfflineReconnectAt[serial]; ok && time.Since(last) < cooldown {
		androidOfflineReconnectMu.Unlock()
		return
	}
	androidOfflineReconnectAt[serial] = time.Now()
	androidOfflineReconnectMu.Unlock()

	logger.ProviderLogger.LogInfof("android_reconnect", "Device %s is offline in ADB, attempting reconnect", serial)
	cmd := exec.CommandContext(context.Background(), "adb", "-s", serial, "reconnect")
	if err := cmd.Run(); err != nil {
		logger.ProviderLogger.LogErrorf("android_reconnect", "Failed to reconnect device %s: %v", serial, err)
	} else {
		logger.ProviderLogger.LogInfof("android_reconnect", "Reconnect issued for device %s", serial)
	}
}

// Gets the connected android devices using `adb`
func getConnectedDevicesAndroid() []string {
	var connectedDevices []string

	cmd := exec.Command("adb", "devices")
	// Create a pipe to capture the command's output
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		logger.ProviderLogger.LogDebugf("provider", "getConnectedDevicesAndroid: Creating exec cmd StdoutPipe failed, returning empty slice - %s", err)
		return connectedDevices
	}

	err = cmd.Start()
	if err != nil {
		logger.ProviderLogger.LogDebugf("provider", "getConnectedDevicesAndroid: Error executing `%s` , returning empty slice - %s", cmd.Args, err)
		return connectedDevices
	}

	// Create a scanner to read the command's output line by line
	scanner := bufio.NewScanner(stdout)

	for scanner.Scan() {
		line := scanner.Text()
		if line == "" || strings.Contains(line, "List of devices") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		udid, status := fields[0], fields[1]
		switch status {
		case "device":
			connectedDevices = append(connectedDevices, udid)
		case "offline":
			go reconnectOfflineAndroid(udid)
		}
	}

	err = cmd.Wait()
	if err != nil {
		logger.ProviderLogger.LogDebugf("provider", "getConnectedDevicesAndroid: Waiting for `%s` command to finish failed, returning empty slice - %s", cmd.Args, err)
		return []string{}
	}

	return connectedDevices
}
