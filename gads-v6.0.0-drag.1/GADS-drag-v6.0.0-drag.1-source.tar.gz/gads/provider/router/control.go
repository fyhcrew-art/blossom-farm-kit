package router

// MODIFIED FILE - NOT THE ORIGINAL GADS FILE.
// Changed by Blossom CRM (https://github.com/fyhcrew-art/blossom-farm-kit),
// November 2026: added the custom actions "drag", "source" and
// "open_url" (deviceDrag, wdaSessionID, deviceOpenURL and three cases in
// executeCustomAction).
// The changes are under the GNU AGPL v3.0, like the original file.

import (
	"GADS/common/models"
	"GADS/common/utils"
	"GADS/provider/config"
	"GADS/provider/devices"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os/exec"
	"strconv"
	"time"

	"github.com/danielpaulus/go-ios/ios/instruments"
)

var controlNetClient = &http.Client{
	Timeout: time.Second * 120,
}

func androidRemoteServerRequest(dev devices.PlatformDevice, method, endpoint string, requestBody io.Reader) (*http.Response, error) {
	andDev, ok := dev.(*devices.AndroidDevice)
	if !ok {
		return nil, fmt.Errorf("device %s is not an Android device", dev.GetUDID())
	}
	url := fmt.Sprintf("http://localhost:%s/%s", andDev.GetAndroidRemoteServerPort(), endpoint)
	dev.GetLogger().LogDebugf("androidRemoteServerRequest", "Calling `%s` for device `%s`", url, dev.GetUDID())
	req, err := http.NewRequest(method, url, requestBody)
	if err != nil {
		return nil, err
	}
	return controlNetClient.Do(req)
}

func androidRemoteServerRequestJson(dev devices.PlatformDevice, method, endpoint string, requestBody io.Reader) (*http.Response, error) {
	andDev, ok := dev.(*devices.AndroidDevice)
	if !ok {
		return nil, fmt.Errorf("device %s is not an Android device", dev.GetUDID())
	}
	url := fmt.Sprintf("http://localhost:%s/%s", andDev.GetAndroidRemoteServerPort(), endpoint)
	dev.GetLogger().LogDebugf("androidRemoteServerRequest", "Calling `%s` for device `%s`", url, dev.GetUDID())
	req, err := http.NewRequest(method, url, requestBody)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	return controlNetClient.Do(req)
}

func appiumRequest(dev devices.PlatformDevice, method, endpoint string, requestBody io.Reader) (*http.Response, error) {
	url := fmt.Sprintf("http://localhost:%s/session/%s/%s", dev.GetAppiumPort(), dev.GetAppiumSessionID(), endpoint)
	dev.GetLogger().LogDebugf("appium_interact", "Calling `%s` for device `%s`", url, dev.GetUDID())
	req, err := http.NewRequest(method, url, requestBody)
	if err != nil {
		return nil, err
	}
	return controlNetClient.Do(req)
}

func appiumRequestNoSession(dev devices.PlatformDevice, method, endpoint string, requestBody io.Reader) (*http.Response, error) {
	url := fmt.Sprintf("http://localhost:%s/%s", dev.GetAppiumPort(), endpoint)
	dev.GetLogger().LogDebugf("appium_interact", "Calling `%s` for device `%s`", url, dev.GetUDID())
	req, err := http.NewRequest(method, url, requestBody)
	if err != nil {
		return nil, err
	}
	return controlNetClient.Do(req)
}

func wdaRequest(dev devices.PlatformDevice, method, endpoint string, requestBody io.Reader) (*http.Response, error) {
	iosDev, ok := dev.(*devices.IOSDevice)
	if !ok {
		return nil, fmt.Errorf("device %s is not an iOS device", dev.GetUDID())
	}
	url := fmt.Sprintf("http://localhost:%v/%s", iosDev.GetWDAPort(), endpoint)
	dev.GetLogger().LogDebugf("wda_interact", "Calling `%s` for device `%s`", url, dev.GetUDID())
	req, err := http.NewRequest(method, url, requestBody)
	if err != nil {
		return nil, err
	}
	return controlNetClient.Do(req)
}

func deviceLock(dev devices.PlatformDevice, lock string) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		return wdaRequest(dev, http.MethodPost, "wda/"+lock, nil)
	} else {
		return androidRemoteServerRequest(dev, http.MethodPost, lock, nil)
	}
}

func deviceTap(dev devices.PlatformDevice, x float64, y float64) (*http.Response, error) {
	requestBody := struct {
		X float64 `json:"x"`
		Y float64 `json:"y"`
	}{
		X: x,
		Y: y,
	}
	actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
	if err != nil {
		return nil, err
	}

	if dev.GetOS() == "ios" {
		return wdaRequest(dev, http.MethodPost, "wda/tap", bytes.NewReader(actionJSON))
	} else {
		return androidRemoteServerRequestJson(dev, http.MethodPost, "tap", bytes.NewReader([]byte(actionJSON)))
	}
}

func deviceTouchAndHold(dev devices.PlatformDevice, x float64, y float64, duration float64) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		duration = float64(duration) / 1000
	}
	requestBody := struct {
		X        float64 `json:"x"`
		Y        float64 `json:"y"`
		Duration float64 `json:"duration"`
	}{
		X:        x,
		Y:        y,
		Duration: duration,
	}
	actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
	if err != nil {
		return nil, err
	}

	if dev.GetOS() == "ios" {
		return wdaRequest(dev, http.MethodPost, "wda/touchAndHold", bytes.NewReader(actionJSON))
	} else {
		return androidRemoteServerRequestJson(dev, http.MethodPost, "touchAndHold", bytes.NewReader([]byte(actionJSON)))
	}
}

// androidScreenshot captures a screenshot from the given Android device.
// displayID is the physical display ID to pass via `screencap -d`; pass empty string
// to let screencap choose the default display (single-display devices).
func androidScreenshot(serial, displayID string) ([]byte, error) {
	args := []string{"-s", serial, "exec-out", "screencap", "-p"}
	if displayID != "" {
		args = append(args, "-d", displayID)
	}

	var out bytes.Buffer
	cmd := exec.Command("adb", args...)
	cmd.Stdout = &out
	if err := cmd.Run(); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}

func deviceScreenshot(dev devices.PlatformDevice) (string, error) {
	if dev.GetOS() == "android" {
		andDev, ok := dev.(*devices.AndroidDevice)
		if !ok {
			return "", fmt.Errorf("device %s is not an Android device", dev.GetUDID())
		}
		imageBytes, err := androidScreenshot(andDev.GetSerial(), andDev.GetActiveDisplayID())
		if err != nil {
			return "", err
		}
		return base64.StdEncoding.EncodeToString(imageBytes), nil
	} else {
		iosDev, ok := dev.(*devices.IOSDevice)
		if !ok {
			return "", fmt.Errorf("device %s is not an iOS device", dev.GetUDID())
		}
		screenshotService, err := instruments.NewScreenshotService(iosDev.GoIOSDeviceEntry)
		if err != nil {
			return "", err
		}
		imageBytes, err := screenshotService.TakeScreenshot()
		if err != nil {
			return "", err
		}

		base64Screenshot := base64.StdEncoding.EncodeToString(imageBytes)

		return base64Screenshot, nil
	}
}

func deviceSwipe(dev devices.PlatformDevice, x, y, endX, endY float64) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		requestBody := struct {
			X     float64 `json:"startX"`
			Y     float64 `json:"startY"`
			EndX  float64 `json:"endX"`
			EndY  float64 `json:"endY"`
			Delay float64 `json:"delay"`
		}{
			X:     x,
			Y:     y,
			EndX:  endX,
			EndY:  endY,
			Delay: 1,
		}
		actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
		if err != nil {
			return nil, err
		}
		return wdaRequest(dev, http.MethodPost, "wda/swipe", bytes.NewReader(actionJSON))
	} else {
		requestBody := struct {
			X     float64 `json:"x1"`
			Y     float64 `json:"y1"`
			EndX  float64 `json:"x2"`
			EndY  float64 `json:"y2"`
			Delay float64 `json:"duration"`
		}{
			X:     x,
			Y:     y,
			EndX:  endX,
			EndY:  endY,
			Delay: 500,
		}
		actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
		if err != nil {
			return nil, err
		}
		return androidRemoteServerRequestJson(dev, http.MethodPost, "swipe", bytes.NewReader([]byte(actionJSON)))
	}
}

func devicePinch(dev devices.PlatformDevice, x, y, scale float64) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		requestBody := struct {
			CenterX    float64 `json:"centerX"`
			CenterY    float64 `json:"centerY"`
			StartScale float64 `json:"startScale"`
			EndScale   float64 `json:"endScale"`
			Duration   float64 `json:"duration"`
		}{
			CenterX:    x,
			CenterY:    y,
			StartScale: 1.0,
			EndScale:   scale,
			Duration:   0.5,
		}

		actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
		if err != nil {
			return nil, fmt.Errorf("failed to marshal iOS pinch payload: %w", err)
		}

		return wdaRequest(dev, http.MethodPost, "wda/pinch", bytes.NewReader(actionJSON))
	} else {
		requestBody := struct {
			CenterX   float64 `json:"centerX"`
			CenterY   float64 `json:"centerY"`
			Scale     float64 `json:"scale"`
			Duration  int     `json:"duration"`
			Direction string  `json:"direction"`
		}{
			CenterX:   x,
			CenterY:   y,
			Scale:     scale,
			Duration:  300,
			Direction: "diagonal",
		}

		actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
		if err != nil {
			return nil, fmt.Errorf("failed to marshal Android pinch payload: %w", err)
		}

		return androidRemoteServerRequestJson(dev, http.MethodPost, "pinch", bytes.NewReader(actionJSON))
	}
}

// deviceDrag presses at the start point, holds still for holdTime seconds so
// the app picks up what is under the finger, then moves it to the end point
// in small steps over dragDuration seconds and lifts. Apps such as Instagram
// read a plain swipe (or a one-jump drag) as a flick or move the sticker only
// part of the way; a held, gradual drag moves it like a finger does.
//
// On iOS it goes through WebDriverAgent's W3C actions endpoint, which needs a
// WDA session; one is reused if open, else created (no app is launched).
// Android falls back to a swipe.
func deviceDrag(dev devices.PlatformDevice, x, y, endX, endY, holdTime, dragDuration float64) (*http.Response, error) {
	if dev.GetOS() != "ios" {
		return deviceSwipe(dev, x, y, endX, endY)
	}

	const steps = 15
	holdMs := int(holdTime * 1000)
	stepMs := int(dragDuration * 1000 / steps)
	if stepMs < 10 {
		stepMs = 10
	}
	actions := []map[string]any{
		{"type": "pointerMove", "duration": 0, "x": x, "y": y},
		{"type": "pointerDown", "button": 0},
		// A move to the same point rather than a pause, so the finger
		// stays put for the whole hold.
		{"type": "pointerMove", "duration": holdMs, "x": x, "y": y},
	}
	for i := 1; i <= steps; i++ {
		f := float64(i) / steps
		actions = append(actions, map[string]any{
			"type": "pointerMove", "duration": stepMs,
			"x": x + (endX-x)*f, "y": y + (endY-y)*f,
		})
	}
	actions = append(actions,
		map[string]any{"type": "pointerMove", "duration": 100, "x": endX, "y": endY},
		map[string]any{"type": "pointerUp", "button": 0},
	)
	payload, err := json.Marshal(map[string]any{
		"actions": []map[string]any{{
			"type":       "pointer",
			"id":         "finger1",
			"parameters": map[string]any{"pointerType": "touch"},
			"actions":    actions,
		}},
	})
	if err != nil {
		return nil, err
	}

	sessionID, err := wdaSessionID(dev, false)
	if err != nil {
		return nil, err
	}
	resp, err := wdaRequest(dev, http.MethodPost, "session/"+sessionID+"/actions", bytes.NewReader(payload))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode == http.StatusNotFound {
		// The session went away (WDA restarted); open a new one and retry once.
		resp.Body.Close()
		if sessionID, err = wdaSessionID(dev, true); err != nil {
			return nil, err
		}
		return wdaRequest(dev, http.MethodPost, "session/"+sessionID+"/actions", bytes.NewReader(payload))
	}
	return resp, nil
}

// wdaSessionID returns WebDriverAgent's open session, creating one when there
// is none or when fresh is set. Creating it without a bundle ID attaches to
// whatever app is in front and launches nothing.
func wdaSessionID(dev devices.PlatformDevice, fresh bool) (string, error) {
	if !fresh {
		resp, err := wdaRequest(dev, http.MethodGet, "status", nil)
		if err != nil {
			return "", err
		}
		var status struct {
			SessionID string `json:"sessionId"`
		}
		err = json.NewDecoder(resp.Body).Decode(&status)
		resp.Body.Close()
		if err == nil && status.SessionID != "" {
			return status.SessionID, nil
		}
	}

	body := []byte(`{"capabilities":{"alwaysMatch":{},"firstMatch":[{}]}}`)
	resp, err := wdaRequest(dev, http.MethodPost, "session", bytes.NewReader(body))
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var created struct {
		SessionID string `json:"sessionId"`
		Value     struct {
			SessionID string `json:"sessionId"`
		} `json:"value"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&created); err != nil {
		return "", fmt.Errorf("creating WDA session: %w", err)
	}
	if created.SessionID != "" {
		return created.SessionID, nil
	}
	if created.Value.SessionID != "" {
		return created.Value.SessionID, nil
	}
	return "", fmt.Errorf("creating WDA session: no session id in response (HTTP %d)", resp.StatusCode)
}

// deviceOpenURL opens a URL on the phone the way a tapped link would: a
// deep link (googledrive://, instagram://, shortcuts://) lands in its app, a
// plain https:// in Safari. WebDriverAgent only serves it inside a session,
// so one is reused or opened like deviceDrag does.
func deviceOpenURL(dev devices.PlatformDevice, rawURL string) (*http.Response, error) {
	if dev.GetOS() != "ios" {
		return nil, fmt.Errorf("open_url is only available for iOS devices")
	}
	if rawURL == "" {
		return nil, fmt.Errorf("url is required")
	}
	payload, err := json.Marshal(map[string]string{"url": rawURL})
	if err != nil {
		return nil, err
	}

	sessionID, err := wdaSessionID(dev, false)
	if err != nil {
		return nil, err
	}
	resp, err := wdaRequest(dev, http.MethodPost, "session/"+sessionID+"/url", bytes.NewReader(payload))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode == http.StatusNotFound {
		resp.Body.Close()
		if sessionID, err = wdaSessionID(dev, true); err != nil {
			return nil, err
		}
		return wdaRequest(dev, http.MethodPost, "session/"+sessionID+"/url", bytes.NewReader(payload))
	}
	return resp, nil
}

func deviceDoubleTap(dev devices.PlatformDevice, x, y float64) (*http.Response, error) {
	requestBody := struct {
		X float64 `json:"x"`
		Y float64 `json:"y"`
	}{
		X: x,
		Y: y,
	}
	actionJSON, err := json.MarshalIndent(requestBody, "", "  ")
	if err != nil {
		return nil, err
	}

	if dev.GetOS() == "ios" {
		return wdaRequest(dev, http.MethodPost, "wda/doubleTap", bytes.NewReader(actionJSON))
	}

	return androidRemoteServerRequestJson(dev, http.MethodPost, "doubleTap", bytes.NewReader(actionJSON))
}

func deviceHome(dev devices.PlatformDevice) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		return wdaRequest(dev, http.MethodPost, "wda/homescreen", nil)
	} else {
		return androidRemoteServerRequest(dev, http.MethodPost, "home", nil)
	}
}

func iOSAppSwitcher(dev devices.PlatformDevice) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		w, _ := strconv.ParseFloat(dev.GetDBDevice().ScreenWidth, 64)
		h, _ := strconv.ParseFloat(dev.GetDBDevice().ScreenHeight, 64)
		body := map[string]float64{"screenWidth": w, "screenHeight": h, "duration": 1}
		data, err := json.Marshal(body)
		if err != nil {
			return nil, err
		}
		reader := bytes.NewReader(data)
		return wdaRequest(dev, http.MethodPost, "wda/appSwitcher", reader)
	}
	return nil, fmt.Errorf("Device is not an iOS device")
}

func androidRecents(dev devices.PlatformDevice) error {
	if dev.GetOS() == "android" {
		cmd := exec.CommandContext(dev.GetContext(), "adb", "-s", dev.GetSerial(), "shell", "input", "keyevent", "KEYCODE_APP_SWITCH")
		return cmd.Run()
	}
	return fmt.Errorf("Device is not an Android device")
}

func activateApp(dev devices.PlatformDevice, appIdentifier string) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		requestBody := struct {
			BundleId string `json:"bundleId"`
		}{
			BundleId: appIdentifier,
		}

		reqJson, err := json.MarshalIndent(requestBody, "", "  ")
		if err != nil {
			return nil, fmt.Errorf("appiumActivateApp: Failed to marshal request body json when activating app for device `%s` - %s", dev.GetUDID(), err)
		}

		return wdaRequest(dev, http.MethodPost, "wda/apps/activate", bytes.NewReader(reqJson))
	}

	return nil, fmt.Errorf("App activation available only for iOS devices")
}

func deviceGetClipboard(dev devices.PlatformDevice) (*http.Response, error) {
	if dev.GetOS() == "ios" {
		requestBody := struct {
			ContentType string `json:"contentType"`
		}{
			ContentType: "plaintext",
		}
		reqJson, err := json.MarshalIndent(requestBody, "", "  ")
		if err != nil {
			return nil, fmt.Errorf("appiumGetClipboard: Failed to marshal request body json when getting clipboard for device `%s` - %s", dev.GetUDID(), err)
		}

		activateAppResp, err := activateApp(dev, config.ProviderConfig.WdaBundleID)
		if err != nil {
			return activateAppResp, fmt.Errorf("appiumGetClipboard: Failed to activate app - %s", err)
		}
		defer activateAppResp.Body.Close()

		clipboardResp, err := wdaRequest(dev, http.MethodPost, "wda/getPasteboard", bytes.NewReader(reqJson))
		if err != nil {
			return clipboardResp, fmt.Errorf("appiumGetClipboard: Failed to execute Appium request for device `%s` - %s", dev.GetUDID(), err)
		}

		_, err = deviceHome(dev)
		if err != nil {
			dev.GetLogger().LogWarn("appium_interact", "appiumGetClipboard: Failed to navigate to Home/Springboard using Appium")
		}

		return clipboardResp, nil
	} else {
		return androidRemoteServerRequest(dev, http.MethodPost, "clipboard", nil)
	}
}

func executeTypeText(dev devices.PlatformDevice, text string) (*http.Response, error) {
	typeTextPayload := models.AppiumTypeText{
		Text: text,
	}
	typeJSON, err := json.MarshalIndent(typeTextPayload, "", "  ")
	if err != nil {
		return nil, err
	}

	if dev.GetOS() == "ios" {
		return wdaRequest(dev, http.MethodPost, "wda/type", bytes.NewBuffer(typeJSON))
	} else {
		andDev, ok := dev.(*devices.AndroidDevice)
		if !ok {
			return nil, fmt.Errorf("device %s is not an Android device", dev.GetUDID())
		}
		req, err := http.NewRequest(http.MethodPost, fmt.Sprintf("http://localhost:%v/type", andDev.GetAndroidIMEPort()), bytes.NewBuffer(typeJSON))
		if err != nil {
			return nil, err
		}
		return netClient.Do(req)
	}
}

func getCenterCoordinates(dev devices.PlatformDevice) (float64, float64, error) {
	device := dev.GetDBDevice()
	width, err := strconv.ParseFloat(device.ScreenWidth, 64)
	if err != nil {
		return 0, 0, fmt.Errorf("invalid screen width %q: %w", device.ScreenWidth, err)
	}

	height, err := strconv.ParseFloat(device.ScreenHeight, 64)
	if err != nil {
		return 0, 0, fmt.Errorf("invalid screen height %q: %w", device.ScreenHeight, err)
	}

	return width / 2, height / 2, nil
}

func normalizeCoordinates(dev devices.PlatformDevice, x, y float64) (float64, float64, error) {
	if x == 0 && y == 0 {
		return getCenterCoordinates(dev)
	}
	return x, y, nil
}

func executeCustomAction(dev devices.PlatformDevice, actionType string, params map[string]any) (*http.Response, error) {
	if params == nil {
		params = make(map[string]any)
	}

	switch actionType {
	case "tap":
		x := utils.GetFloat(params, "x", 0)
		y := utils.GetFloat(params, "y", 0)
		x, y, err := normalizeCoordinates(dev, x, y)
		if err != nil {
			return nil, fmt.Errorf("normalizing coordinates: %w", err)
		}
		return deviceTap(dev, x, y)

	case "double_tap":
		x := utils.GetFloat(params, "x", 0)
		y := utils.GetFloat(params, "y", 0)
		x, y, err := normalizeCoordinates(dev, x, y)
		if err != nil {
			return nil, fmt.Errorf("normalizing coordinates: %w", err)
		}
		return deviceDoubleTap(dev, x, y)

	case "swipe":
		x := utils.GetFloat(params, "x", 0)
		y := utils.GetFloat(params, "y", 0)
		endX := utils.GetFloat(params, "endX", 0)
		endY := utils.GetFloat(params, "endY", 0)
		return deviceSwipe(dev, x, y, endX, endY)

	case "touch_and_hold":
		x := utils.GetFloat(params, "x", 0)
		y := utils.GetFloat(params, "y", 0)
		x, y, err := normalizeCoordinates(dev, x, y)
		if err != nil {
			return nil, fmt.Errorf("normalizing coordinates: %w", err)
		}
		duration := utils.GetFloat(params, "duration", 1000)
		return deviceTouchAndHold(dev, x, y, duration)

	case "pinch":
		x := utils.GetFloat(params, "x", 0)
		y := utils.GetFloat(params, "y", 0)
		x, y, err := normalizeCoordinates(dev, x, y)
		if err != nil {
			return nil, fmt.Errorf("normalizing coordinates: %w", err)
		}
		scale := utils.GetFloat(params, "scale", 1.0)
		return devicePinch(dev, x, y, scale)

	case "type_text":
		text := utils.GetString(params, "text", "")
		return executeTypeText(dev, text)

	case "home":
		return deviceHome(dev)

	case "lock":
		return deviceLock(dev, "lock")

	case "unlock":
		return deviceLock(dev, "unlock")

	case "drag":
		x := utils.GetFloat(params, "x", 0)
		y := utils.GetFloat(params, "y", 0)
		endX := utils.GetFloat(params, "endX", 0)
		endY := utils.GetFloat(params, "endY", 0)
		holdTime := utils.GetFloat(params, "holdTime", 0.5)
		dragDuration := utils.GetFloat(params, "dragDuration", 0.8)
		return deviceDrag(dev, x, y, endX, endY, holdTime, dragDuration)

	case "source":
		// The screen's element tree (types, labels, frames) as WebDriverAgent
		// sees it, without a session: what the dashboard's phone assistant
		// reads instead of guessing from a screenshot.
		return wdaRequest(dev, http.MethodGet, "source?format=json", nil)

	case "open_url":
		return deviceOpenURL(dev, utils.GetString(params, "url", ""))

	case "pinch_in":
		x := utils.GetFloat(params, "x", 250)
		y := utils.GetFloat(params, "y", 500)
		return devicePinch(dev, x, y, 0.5)

	case "pinch_out":
		x := utils.GetFloat(params, "x", 250)
		y := utils.GetFloat(params, "y", 500)
		return devicePinch(dev, x, y, 2.0)

	default:
		return nil, fmt.Errorf("unsupported action type: %s", actionType)
	}
}
